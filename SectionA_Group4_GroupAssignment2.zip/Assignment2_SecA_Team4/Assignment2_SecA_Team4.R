##########################
#  Group Member Details  #
##########################

# Group Number: 04
# Section: A

################
#Group Members:#
################

# PGCBAA02A019 Gorle Mohan Rao
# PGCBAA02A055 SAYAM ROY
# PGCBAA02A058 SHIVANGI PANDEY
# PGCBAA02A060 Shristi Shah
# PGCBAA02A071 Vaibhav Rajaram Thakur
# PGCBAA02A008 Ashwinee Kumar

##############################################################################################################################################################
# 1. The following questions should be answered using the ’Carseats’ data set. The dataset is attached.You can find the details about the dataset            #
#    here https://rdrr.io/cran/ISLR/man/Carseats.html                                                                                                        #
#                                                                                                                                                            #
#     (a) Perform univariate and bivariate Analysis.                                                                                                         #
#     (b) Fit a multiple regression model to predict ’Sales’ using ’Price’, ’Urban’, and ’US’.                                                               #
#     (c) Provide an interpretation of each coefficient in the model.                                                                                        #
#     (d) Use the stepwise procedure to develop the best estimated regression equation.                                                                      #
#     (e) Write out the model in equation form.                                                                                                              #
##############################################################################################################################################################
# get the current working directory
getwd()

# set the working directory
setwd("C:/Users/91882/Desktop/IIMT-Day1/Term 4/Modelling with R/Group Assignment 2/Assignment2_SecA_Team4") # set your own working directory here

# Loading required packages
library(readr)

# Importing Excel Data into Data frame
Carseats_data <- read_csv("Carseats.csv")
#spec(Carseats_data)
View(Carseats_data)

#****************************************************************************************************************************************
#                                        Univariate Analysis For Continuous/Categorical Variables                                       *
#****************************************************************************************************************************************

library(summarytools)

# Summary statistics(centrality and spread) and Graphical Representation
#view(dfSummary(Carseats_data),file = "C:/Users/91882/Desktop/IIMT-Day1/Term 4/Modelling with R/Group Assignment 2/Assignment2_SecA_Team4/Carseats_dfsummary.html" )

# Print result as html output
print(
  dfSummary(Carseats_data),
  file = "C:/Users/91882/Desktop/IIMT-Day1/Term 4/Modelling with R/Group Assignment 2/Assignment2_SecA_Team4/Carseats_dfsummary.html"
  )

#****************************************************************************************************************************************
#                                         Bivariate Analysis For Continuous/Categorical Variables                                       *
#****************************************************************************************************************************************

library(GGally)
library(dplyr)

# 1. Creating pairs plot showing the interactions of each variable with each of the others, With respect to Categorical Variable- US
US<- Carseats_data%>% 
     dplyr::select(everything()) %>%
     ggpairs(mapping = aes(color = Carseats_data$US, alpha = 0.5))

ggsave("Pairplot-US.pdf",plot = US,device = NULL,width = 15, height = 15)

# 2. Creating pairs plot showing the interactions of each variable with each of the others, With respect to Categorical Variable- Urban
Urban<- Carseats_data %>% 
  dplyr::select(everything()) %>%
  ggpairs(mapping = aes(color = Carseats_data$Urban, alpha = 0.5))

ggsave("Pairplot-Urban.pdf",plot = Urban,device = NULL,width = 15, height = 15)

# 3. Creating pairs plot showing the interactions of each variable with each of the others, With respect to Categorical Variable- ShelveLocation
ShelveLocation<- Carseats_data %>% 
  dplyr::select(everything()) %>%
  ggpairs(mapping = aes(color = Carseats_data$ShelveLoc, alpha = 0.5))

ggsave("Pairplot-ShelveLocation.pdf",plot = ShelveLocation,device = NULL,width = 15, height = 15)

#****************************************************************************************************************************************
#                        Fit a multiple regression model to predict ’Sales’ using ’Price’, ’Urban’, and ’US’.                           *
#****************************************************************************************************************************************

#Creating fit 
model_Price_Urban_US = lm(data=Carseats_data,formula = Sales~Price+Urban+US)
summary(model_Price_Urban_US)

library(car)

#Checking for Regression Model Assumptions To get meaningful Prediction
qqPlot(model_Price_Urban_US) #Normality
crPlots(model_Price_Urban_US) #Linearity
ncvTest(model_Price_Urban_US) #Homoscedasticity

#Predicting for existing values
head(predict(model_Price_Urban_US))

#Predicting for new observation
predict(model_Price_Urban_US,newdata = data.frame(Price=101,Urban='Yes',US='Yes'))

#****************************************************************************************************************************************
#                                       Provide an interpretation of each coefficient in the model.                                     *
#****************************************************************************************************************************************
#*
#* Price and US are significant variables and Urban is not significant in determining Sales
#* Sales decreases by 0.0545 units(estimate) corresponding to one unit increase in price ,when all other independent variables are constant.
#* If it is US( (US - Yes), then sales increases by 1.2 units(estimate) compared to outside US (US - No)
#* If Urban categorical variable was significant and it was Urban( (Urban - Yes), then sales would decrease by 0.022 units(estimate) 
#* compared to not Urban (Urban - No). But as the p - value(0.936) is greater than 0.05 , Urban is not significant.

#****************************************************************************************************************************************
#                             Use the stepwise procedure to develop the best estimated regression equation.                             *
#****************************************************************************************************************************************
#*
library(leaps)
library(Metrics)
library(MASS)
# adding seed for reproducibility

set.seed(999)
train_dataset <- sample(nrow(Carseats_data),0.7 * nrow(Carseats_data))

# splitting into training data
train.split <- Carseats_data[train_dataset,]

#splitting into test data
test.split <- Carseats_data[-train_dataset,]

#Creating linear model based on training data
fit <- lm(Sales ~ .,data = train.split )

#Visualization using leaps
leaps <- regsubsets(Sales ~ .,data = train.split ,nbest = 2)
plot(leaps, scale = "adjr2")

#Creating fit without any variable
fit0 <- lm(Sales ~ 1, data = train.split)

#Creating stepwise Regression model
stepwise.model <- stepAIC(fit0,direction = "both", scope = list(upper = fit , lower = ~1))


# Sales ~ ShelveLoc + Price + CompPrice + Advertising + Age + Income (linear model with minimum AIC-34.89)
ypredict.test <- predict(stepwise.model, newdata = test.split)

# error between actual and forecasted
error <- (test.split$Sales - ypredict.test)

#Compute RMSE
RMSE <- sqrt(mean(error^2))
print(RMSE)

#****************************************************************************************************************************************
#                                                Write out the model in equation form.                                                  *
#****************************************************************************************************************************************
#*
#* Creating best estimated fit 
best.fitted.model = lm(data=Carseats_data,formula = Sales ~ ShelveLoc + Price + CompPrice + Advertising + Age + Income)
summary(best.fitted.model)

library(car)

#Checking for Regression Model Assumptions To get meaningful Prediction
qqPlot(best.fitted.model) #Normality
crPlots(best.fitted.model) #Linearity
ncvTest(best.fitted.model) #Homoscedasticity

# Model in equation format(Estimated)
# Sales = 5.475 + 4.836 * ShelveLocGood + 1.952 * ShelveLocMedium + (-0.095) * Price +
#         0.093 * CompPrice + 0.116 * Advertising + (-0.046) * Age + 0.016 * Income


##############################################################################################################################################################################
# Telecommunications companies providing cell phone service are interested in customer retention. In particular, identifying customers who are about to churn (cancel their  #
# service) is potentially worth millions of dollars if the company can proactively address the reason that customer is considering cancellation and retain the customer.     #
# The attached file, Cellphone.xlsx, contains customer data to be used to classify a customer as a churner or not.                                                           #
#     (a) Explore the data. Bring at least two insights from the exploratory data analysis.                                                                                  #  
#     (b) Split the data into train and test (70:30). From the generated set of logistic regression models, select one that you believe is a good fit. Express               #
#         the model as a mathematical equation relating the output variable to the input variables.                                                                          #
#     (c) Using various cutoff values for your logistic regression model and discuss the sensitivity and specificity for the test data                                       #                                                                                                                   #
##############################################################################################################################################################################

# loading required packages
library(readxl)

# reading excel data
tele.customer.data <- read_excel("Cellphone.xlsx",sheet = 2)
View(tele.customer.data)   # uncomment to view result in tab

#****************************************************************************************************************************************
#                          Explore the data. Bring at least two insights from the exploratory data analysis.                            *
#****************************************************************************************************************************************

# Print result as html output
print(
 dfSummary(tele.customer.data),
 file = "C:/Users/91882/Desktop/IIMT-Day1/Term 4/Modelling with R/Group Assignment 2/Assignment2_SecA_Team4/Tele_customer_dfsummary.html"
)

# Finding correlation among different variables
 tele.customer.data%>% 
 dplyr::select(everything())%>%
 ggcorr(label = TRUE)
 
 help(ggcorr)
 
# Boxplot to understand relation for churned customers and calls they made to customer service
 tele.customer.data%>% 
 mutate(customer_churned = if_else(Churn == 0,"No","Yes"))%>%
 ggplot(mapping = aes(x = customer_churned, y = CustServCalls)) +
 geom_boxplot() + scale_y_continuous(breaks=seq(0,9,1))

# Boxplot to understand relation for churned customers and average daytime minutes per month available to them
 tele.customer.data%>% 
  mutate(customer_churned = if_else(Churn == 0,"No","Yes"))%>%
 ggplot(mapping = aes(x = customer_churned, y = DayMins)) +
 geom_boxplot() + scale_y_continuous(breaks=seq(0,500,75))
 
 
# Scatterplot to understand relation between dayMins and Monthly Charges
 # 1. open a file 
 jpeg("Scatter Plot - Monthly Charge Vs Minutes.jpg")
 
 scatterplot(MonthlyCharge ~ DayMins | Churn, data = tele.customer.data)
 
 # close the file
 dev.off()

  tele.customer.data%>% 
   mutate(customer_churned = if_else(Churn == 0,"No","Yes"),has_data = if_else(DataPlan == 0,"No","Yes"))%>%
   ggplot(mapping = aes(x = customer_churned, y = MonthlyCharge, color=has_data)) +
   geom_boxplot() + scale_y_continuous(breaks=seq(0,200,20))
  
  
  tele.customer.data%>% 
    mutate(customer_churned = if_else(Churn == 0,"No","Yes"),has_data = if_else(DataPlan == 0,"No","Yes"))%>%
    ggplot(mapping = aes(x = has_data, y = DataUsage, color=customer_churned)) +
    geom_boxplot() + scale_y_continuous(breaks=seq(0,10,1))

#****************************************************************************************************************************************
# Split the data into train and test (70:30). From the generated set of logistic regression models, select one that you believe is a    *
# good fit. Express the model as a mathematical equation relating the output variable to the input variables.                           *
#****************************************************************************************************************************************

set.seed(999)
tele.train_dataset <- sample(nrow(tele.customer.data),0.7 * nrow(tele.customer.data))
  
# splitting into training data
tele.train.split <- tele.customer.data[train_dataset,]
  
#splitting into test data
tele.test.split <- tele.customer.data[-train_dataset,]

#Creating  logistic model based on training data
fit.1 <- glm(Churn ~ ., family = binomial, data = tele.train.split )

#Creating fit without any variable
fit.0 <- glm(Churn ~ 1,family = binomial, data = tele.train.split)

#Creating stepwise logistic Regression model
stepwise.logistic.model <- stepAIC(fit.0,direction = "both", scope = list(upper = fit.1 , lower = ~1))

#* Creating best estimated fit - logistic regression
fitted.logistic.model.2 = glm(data=tele.train.split,formula =Churn ~ DayMins + CustServCalls + ContractRenewal + DataPlan)
summary(fitted.logistic.model.2)

# Removing data plan from Model as not significant
best.fitted.logistic.model = glm(data=tele.train.split,formula =Churn ~ DayMins + CustServCalls + ContractRenewal)
summary(best.fitted.logistic.model)


# Mathematical Equation for the model
# Churn = 0.0524 + 0.0011 * DayMins + 0.0433 * CustServCalls + (-0.2123) * ContractRenewal

#log(odds) that customer will churn is exp of coeficients likely to churn.Now you can see that the odds of churn are multiplied by a factor of 
#0.0011 for a one unit increase in DayMins (holding CustServCalls constant) and by 0.0433 for one unit increase in CustServCalls and decreases by factor of 0.2123 if contract is renewed 

tele.ypredict.test <- predict(best.fitted.logistic.model, newdata = tele.test.split,type = "response")

#****************************************************************************************************************************************
#     Using various cutoff values for your logistic regression model and discuss the sensitivity and specificity for the test data      *
#****************************************************************************************************************************************
#*
library(caret)
new_df<- tele.test.split%>% 
              mutate(customer_churned = if_else(Churn == 0,"No","Yes"))

#Custom function to calculate Accuracy,sensivity,specificity at different cutoff values
get_logistic_pred = function(model, data, result , positive = 1, negative = 0, cut) {
  probability = predict(model, newdata = data, type = "response")
  ifelse(probability > cut, positive, negative)
}

test_pred_0.3 = get_logistic_pred(best.fitted.logistic.model, data = new_df, res = "customer_churned", 
                                  positive = "Yes", negative = "No", cut = 0.3)
test_pred_0.4 = get_logistic_pred(best.fitted.logistic.model, data = new_df, res = "customer_churned", 
                                  positive = "Yes", negative = "No", cut = 0.4)
test_pred_0.5 = get_logistic_pred(best.fitted.logistic.model, data = new_df, res = "customer_churned", 
                                  positive = "Yes", negative = "No", cut = 0.5)
test_pred_0.7 = get_logistic_pred(best.fitted.logistic.model, data = new_df, res = "customer_churned", 
                                  positive = "Yes", negative = "No", cut = 0.7)

test_table_0.3 = table(predicted = test_pred_0.3, actual = new_df$customer_churned)
test_table_0.4 = table(predicted = test_pred_0.4, actual = new_df$customer_churned)
test_table_0.5 = table(predicted = test_pred_0.5, actual = new_df$customer_churned)
test_table_0.7 = table(predicted = test_pred_0.7, actual = new_df$customer_churned)

test_confusin_matrix_0.3 = confusionMatrix(test_table_0.3, positive = "Yes")
test_confusin_matrix_0.4 = confusionMatrix(test_table_0.4, positive = "Yes")
test_confusin_matrix_0.5 = confusionMatrix(test_table_0.5, positive = "Yes")
test_confusin_matrix_0.7 = confusionMatrix(test_table_0.7, positive = "Yes")

metrics = rbind(
  c(test_confusin_matrix_0.3$overall["Accuracy"], 
    test_confusin_matrix_0.3$byClass["Sensitivity"], 
    test_confusin_matrix_0.3$byClass["Specificity"]),
  
  c(test_confusin_matrix_0.4$overall["Accuracy"], 
    test_confusin_matrix_0.4$byClass["Sensitivity"], 
    test_confusin_matrix_0.4$byClass["Specificity"]),
  
  c(test_confusin_matrix_0.5$overall["Accuracy"], 
    test_confusin_matrix_0.5$byClass["Sensitivity"], 
    test_confusin_matrix_0.5$byClass["Specificity"]),
  
  c(test_confusin_matrix_0.7$overall["Accuracy"], 
    test_confusin_matrix_0.7$byClass["Sensitivity"], 
    test_confusin_matrix_0.7$byClass["Specificity"])
)
rownames(metrics) = c("c = 0.3", "c = 0.4" ,"c = 0.5", "c = 0.7")
metrics



